function estacao1() {
    document.getElementById('estacao').src = 'verao.png';
}
function estacao2() {
    document.getElementById('estacao').src = 'outono.webp';
}
function estacao3() {
    document.getElementById('estacao').src = 'inverno.jpg';
}
function estacao4() {
    document.getElementById('estacao').src = 'primavera.png';
}

