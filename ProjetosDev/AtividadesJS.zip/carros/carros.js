function carro1() {
    document.getElementById('carro').src = "porsche.png";
}
function carro2() {
    document.getElementById('carro').src = "ferrari.png";
}
function carro3() {
    document.getElementById('carro').src = "lamborghini.png";
}
function carro4() {
    document.getElementById('carro').src = "mercedes.png";
}
