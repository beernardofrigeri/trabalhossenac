function lua1() {
    document.querySelector('img').src = 'lua_crescente.webp';
}
function lua2() {
    document.querySelector('img').src = 'lua.webp';
}
function lua3() {
    document.querySelector('img').src = 'lua_minguante.webp';
}
function lua4() {
    document.querySelector('img').src = 'lua_nova.webp';
}
