function ligar() {
    var lampada = document.getElementById('lampada').src = "1.jpg";
}
function desligar() {
    var lampada = document.getElementById('lampada').src = "2.png";
}
