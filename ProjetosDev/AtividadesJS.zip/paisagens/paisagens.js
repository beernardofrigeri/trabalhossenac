function paisagem1() {
    document.getElementById('paisagem').src = 'paisagem1.jpg';
}
function paisagem2() {
    document.getElementById('paisagem').src = 'paisagem2.jpg';
}
function paisagem3() {
    document.getElementById('paisagem').src = 'paisagem3.jpg';
}
function paisagem4() {
    document.getElementById('paisagem').src = 'paisagem4.jpg';
}
